<h1> Convertor LTDS (List, Tuple, Dictionary, Set) </h1>
This Package Contains convert.py Module.
  <br>
<h2> Usage </h2>
Type "pip install Convertor-LTDS" to install package.

Type "from convert_ltds import convert"

<h3> Example </h3>

```python
>>>from convert_ltds import convert
>>>alphabets = ["A", "B", "C", "D"]
>>>tuple_alphabets = convert.to_tuple(alphabets)
>>>print(tuple_alphabets)
```

**Output: ("A", "B", "C", "D")**

<h2> Suggestions </h2>

You can give me suggestions on https://github.com/Benefit-Zebra/Convertor-LTDS
#FeelingLonely

Note: I have problem on converting to set datatype. You can give suggestions.