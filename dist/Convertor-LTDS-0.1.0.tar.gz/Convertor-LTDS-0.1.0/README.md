<h1> Convertor LTDS (List,Tuple,Dictionary,Set) </h1>
This Package Contains convert.py Module.
  <br>
<h2> Usage </h2>
import "convert" module and use its functions to converts between these four.