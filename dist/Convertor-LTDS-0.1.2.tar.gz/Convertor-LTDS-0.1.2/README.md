<h1> Convertor LTDS (List, Tuple, Dictionary, Set) </h1>
This Package Contains convert.py Module.
  <br>
<h2> Usage </h2>
Type "pip install Convertor-LTDS" to install package.

Type "from convert_ltds import convert" and use its functions to converts between List, Tuple, Dictionary,and Set.
